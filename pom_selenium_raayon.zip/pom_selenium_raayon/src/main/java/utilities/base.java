package utilities;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;

public class base {
	protected static String driverPath = "C://My_files/Java/Automation/geckodriver.exe";
	protected static String edgeDriverPath = "C://My_files/Java/Automation/edgedriver_win32/msedgedriver.exe";
	public static WebDriver driver;
	public static Map<String, String> parametersDictionary = new HashMap<String, String>();
	public static String todayDate;

}
