package utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;


/**
 * 
 * @param Dima
 *
 */

//Parameters [name=Homepage, param=http://automationpractice.com/]
public class ReadCSV_4 extends base{
	

	    public static void main(String... args) {
	    	parametersDictionary= readParameterss_1FromCSV("C:/My_files/Java/Automation/Parameters_3.csv");

	        //  print data from CSV file
	        
	        //    System.out.println(parametersDictionary.get("Homepage"));
	       
	    }

	    private static Map<String, String> readParameterss_1FromCSV(String fileName) {

	        Path pathToFile = Paths.get(fileName);
	        try (BufferedReader br = Files.newBufferedReader(pathToFile,
	                StandardCharsets.US_ASCII)) {

	            // read the first line from the text file
	            String line = br.readLine();

	            // loop until all lines are read
	            while (line != null) {
	                
	            	parametersDictionary.put(line.substring(0, line.indexOf(",")),line.substring( line.indexOf(",")+1,line.length()));

	                line = br.readLine();
	            }

	        } catch (IOException ioe) {
	            ioe.printStackTrace();
	        }

	        return parametersDictionary;
	    }


	}

