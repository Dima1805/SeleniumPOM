package utilities;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  
public class utils extends base{  
	  public static void main(String[] args) {    
	   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd_MM_yy_HH_mm_ss");  
	   LocalDateTime now = LocalDateTime.now();  
	   todayDate=dtf.format(now);
	    
	  }    
	} 