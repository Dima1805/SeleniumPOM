package pages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class FillFieldsCustomerEmail extends utilities.base {

	WebDriver driver;

	// MrRadioButton
	By MrGender = By.id("id_gender1");

	// MrsRadioButton
	By MrsGender = By.id("id_gender2");

	// Enter firstname
	By PersonalInformationFirstName = By.id("customer_firstname");

	// Enter lastname
	By PersonalInformationLastName = By.id("customer_lastname");

	// Enter password
	By PersonalInformationPassword = By.id("passwd");

	// newsletter
	By PersonalInformationSignUpForOurNewsletter = By.id("newsletter");

	// Enter company
	By YourAdressCompany = By.id("company");

	// Enter YourAdressAddress
	By YourAdressAddress = By.id("address1");

	// Enter YourAdressAddress
	By YourAdressAddressLine2 = By.id("address2");

	// Enter city
	By YourAdressCity = By.id("city");

	// Choose state

	// Enter postcode
	By YourAdressZipPostalCode = By.id("postcode");

	// Choose country

	// Enter YourAdressAdditionalInformation
	By YourAdressAdditionalInformation = By.id("other");

	// Enter phone
	By YourAdressHomePhone = By.id("phone");

	// Enter phone_mobile
	By YourAdressMobilePhone = By.id("phone_mobile");

	// Enter Assign an address alias
	By AddressAliasForFR = By.id("alias");

	// Submit
	By Submit = By.id("submitAccount");

	// public automationpracticeLogin(WebDriver driver){
	public FillFieldsCustomerEmail(WebDriver driver) {
		this.driver = driver;
	}

	// Choose day of birth
	public void choose_day_of_birth() {
		Select dayOfBirth = new Select(driver.findElement(By.name("days")));
		dayOfBirth.selectByValue(parametersDictionary.get("PersonalInformationDayOfBirth"));
	}

	// Choose month of birth
	public void choose_month_of_birth() {
		Select monthOfBirth = new Select(driver.findElement(By.name("months")));
		monthOfBirth.selectByValue(parametersDictionary.get("PersonalInformationMonthOfBirth"));
	}

	// Choose year of birth
	public void choose_year_of_birth() {
		Select yearOfBirth = new Select(driver.findElement(By.name("years")));
		yearOfBirth.selectByValue(parametersDictionary.get("PersonalInformationYearOfBirth"));
	}

	// Choose country
	public void choose_country() {
		Select country = new Select(driver.findElement(By.name("id_country")));
		country.selectByValue(parametersDictionary.get("YourAdressCountry"));
	}

	// Choose usa state
	public void choose_state() {
		Select usaState = new Select(driver.findElement(By.name("id_state")));
		usaState.selectByValue(parametersDictionary.get("YourAdressState"));

	}

	public void fillNewCustomerFields() {

		System.out.println("Fill started_0");

//		new WebDriverWait(driver, 40).until(ExpectedConditions.elementToBeClickable(MrGender));
		
		System.out.println("Fill started_1");

		if (parametersDictionary.get("PersonalInformationTitle").equalsIgnoreCase("Mr")) {
			driver.findElement(MrGender).click();
		} else {
			driver.findElement(MrsGender).click();
		}
		
		System.out.println("Fill started_2");
		// Enter Firstname
		driver.findElement(PersonalInformationFirstName)
				.sendKeys(parametersDictionary.get("PersonalInformationFirstName"));

		// Enter lastname
		driver.findElement(PersonalInformationLastName)
				.sendKeys(parametersDictionary.get("PersonalInformationLastName"));

		// Enter password
		driver.findElement(PersonalInformationPassword)
				.sendKeys(parametersDictionary.get("PersonalInformationPassword"));

		// Choose day of birth
		choose_day_of_birth();

		// Choose month of birth
		choose_month_of_birth();

		// Choose year of birth
		choose_year_of_birth();

		// Newsletter
		if (parametersDictionary.get("PersonalInformationSignUpForOurNewsletter") == "TRUE") {
			driver.findElement(PersonalInformationSignUpForOurNewsletter).click();
		}

		// Enter company
		driver.findElement(YourAdressCompany).sendKeys(parametersDictionary.get("YourAdressCompany"));

		// Enter YourAdressAddress
		driver.findElement(YourAdressAddress).sendKeys(parametersDictionary.get("YourAdressAddress"));

		// Enter YourAdressAddress2
		driver.findElement(YourAdressAddressLine2).sendKeys(parametersDictionary.get("YourAdressAddressLine2"));

		// Enter city
		driver.findElement(YourAdressCity).sendKeys(parametersDictionary.get("YourAdressCity"));

		// Choose state
		choose_state();

		// Enter postcode
		driver.findElement(YourAdressZipPostalCode).sendKeys(parametersDictionary.get("YourAdressZipPostalCode"));

		// Choose country
		choose_country();

		// Enter YourAdressAdditionalInformation
		driver.findElement(YourAdressAdditionalInformation)
				.sendKeys(parametersDictionary.get("YourAdressAdditionalInformation"));

		// Enter phone
		driver.findElement(YourAdressHomePhone).sendKeys(parametersDictionary.get("YourAdressHomePhone"));

		// Enter phone_mobile
		driver.findElement(YourAdressMobilePhone).sendKeys(parametersDictionary.get("YourAdressMobilePhone"));

		// Enter Assign an address alias
		driver.findElement(AddressAliasForFR).sendKeys(parametersDictionary.get("AddressAliasForFR"));
		// Submit
		driver.findElement(Submit).click();
		
		 Assert.assertTrue(driver.getCurrentUrl().toLowerCase().contains("controller=my-account"));

		// http://automationpractice.com/index.php?controller=my-account
	}

}
