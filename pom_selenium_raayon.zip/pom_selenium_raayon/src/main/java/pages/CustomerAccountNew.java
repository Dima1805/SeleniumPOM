package pages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

public class CustomerAccountNew extends utilities.base{
	
    WebDriver driver;

    By emailField = By.xpath("//*[@id=\"email_create\"]");

    By SubmitCreateCustomerButton=By.id("SubmitCreate");

    public CustomerAccountNew(WebDriver driver){

        this.driver = driver;

    }

    public void newCustomerStartCreatingAccount(){
    	
    	driver.findElement(emailField).sendKeys(todayDate+"@gmail.com");

    	driver.findElement(SubmitCreateCustomerButton).click();

    }

}
