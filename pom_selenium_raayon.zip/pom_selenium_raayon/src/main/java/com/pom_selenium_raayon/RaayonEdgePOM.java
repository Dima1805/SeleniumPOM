package com.pom_selenium_raayon;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.CustomerAccountNew;
import pages.FillFieldsCustomerEmail;
import pages.LogIn;

public class RaayonEdgePOM extends utilities.base{

	String urlLoaded="";
    static WebDriver driver;

    @BeforeTest
	    
	    public void startBrowser() {
	        System.setProperty("webdriver.edge.driver", edgeDriverPath);
	        driver = new EdgeDriver();
	        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
            utilities.ReadCSV_4.main();
            utilities.utils.main(null);
            System.out.println(todayDate); 
            driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            
	    	System.out.println(parametersDictionary.get("Homepage"));
	    	driver.get(parametersDictionary.get("Homepage"));

	    }

	    @Test
	    public void CreateNewUser() {
//Enter to MainPage

	    	
	    	 LogIn objLogin = new LogIn(driver);
	    	 CustomerAccountNew CustomerAN = new CustomerAccountNew(driver);
	    	 FillFieldsCustomerEmail FillFCE=new FillFieldsCustomerEmail(driver);
	    	 
	    	 objLogin.signInButton();
	    	 try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	 CustomerAN.newCustomerStartCreatingAccount();
	    	 
	    	 try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	 
	    	 FillFCE.fillNewCustomerFields();
	    	
	    	 try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    
	    }
	        
	    @AfterClass
	        public static void tearDownClass() {
	    	
	            driver.close();
	        }

	    @AfterTest
	    public void endTest() {
	       System.out.println("FinallUrl is: "+urlLoaded);	
	       // driver.quit();
	    }

	}
	


